"""Employee surface. Never exposes the administrative service token to the browser."""
import hmac
import secrets
import time
from pathlib import Path
from urllib.parse import urlsplit

from fastapi import HTTPException, Request, Response
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field


class Login(BaseModel):
    code: str = Field(min_length=1, max_length=256)


class Question(BaseModel):
    query: str = Field(min_length=1, max_length=1000)


def mount_web(app, settings, store, *, preview=False):
    static = Path(__file__).parent / "static"
    app.mount("/assets", StaticFiles(directory=static), name="assets")
    sessions = {}
    attempts = {}
    scopes = list(settings.web_scopes)

    def is_logged_in(request):
        return sessions.get(request.cookies.get("knowledge_session", ""), 0) > time.time()

    def require_session(request):
        if not preview and not is_logged_in(request):
            raise HTTPException(401, "Войдите, чтобы открыть инструкции компании.")

    def same_origin(request):
        origin = request.headers.get("origin")
        if origin and origin.rstrip("/") != str(request.base_url).rstrip("/"):
            raise HTTPException(403, "Откройте помощника по прямой ссылке.")

    def require_fresh():
        states = store.source_states()
        if not scopes or any(s not in states or states[s]["state"] != "ready"
                             or states[s]["checked"] < time.time()-settings.max_stale_seconds for s in scopes):
            raise HTTPException(503, "Инструкции сейчас обновляются или недоступны. Попробуйте немного позже.")

    def safe_url(url):
        if not url:
            return None
        parsed = urlsplit(url)
        return url if parsed.scheme == "https" and parsed.hostname == settings.domain and not parsed.username else None

    @app.middleware("http")
    async def web_headers(request, call_next):
        response = await call_next(request)
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["Referrer-Policy"] = "no-referrer"
        response.headers["Content-Security-Policy"] = (
            "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; "
            "connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'"
        )
        response.headers["Permissions-Policy"] = "camera=(), geolocation=(), microphone=(self)"
        return response

    @app.get("/", include_in_schema=False)
    async def home():
        return FileResponse(static / "index.html")

    @app.get("/api/web/status")
    async def status(request: Request):
        return {"preview": preview, "authenticated": preview or is_logged_in(request),
                "configured": preview or bool(settings.web_access_code and scopes),
                "answer_mode": "source_excerpts", "voice_mode": "browser"}

    @app.post("/api/web/login")
    async def login(body: Login, request: Request, response: Response):
        same_origin(request)
        if not settings.web_access_code or not scopes or preview:
            raise HTTPException(503, "Вход в рабочую базу ещё не настроен.")
        now = time.time()
        for ip in list(attempts):
            if attempts[ip][1] < now-60:
                del attempts[ip]
        ip = request.client.host if request.client else "unknown"
        count, _ = attempts.get(ip, (0, now))
        if count >= 5 or len(attempts) >= 1000:
            raise HTTPException(429, "Слишком много попыток. Подождите минуту.")
        if not hmac.compare_digest(body.code.encode(), settings.web_access_code.encode()):
            attempts[ip] = (count+1, attempts.get(ip, (0, now))[1])
            raise HTTPException(401, "Код не подошёл. Проверьте его у ответственного сотрудника.")
        attempts.pop(ip, None)
        for token in list(sessions):
            if sessions[token] <= now:
                del sessions[token]
        if len(sessions) >= 5000:
            raise HTTPException(503, "Сейчас слишком много подключений. Попробуйте позже.")
        token = secrets.token_urlsafe(32)
        sessions[token] = now+8*3600
        response.set_cookie("knowledge_session", token, max_age=8*3600, httponly=True,
                            secure=settings.web_cookie_secure, samesite="strict", path="/")
        return {"authenticated": True}

    @app.post("/api/web/logout")
    async def logout(request: Request, response: Response):
        same_origin(request)
        sessions.pop(request.cookies.get("knowledge_session", ""), None)
        response.delete_cookie("knowledge_session", path="/")
        return {"authenticated": False}

    @app.post("/api/web/search")
    async def search(body: Question, request: Request):
        same_origin(request)
        require_session(request)
        require_fresh()
        results = store.search(body.query, scopes, settings.max_stale_seconds, 5)
        for item in results:
            item["url"] = safe_url(item["url"])
            item.pop("rank", None)
        return {"results": results, "preview": preview}

    @app.get("/api/web/documents/{scope}/{identity}")
    async def document(scope: str, identity: str, request: Request):
        require_session(request)
        if scope not in scopes:
            raise HTTPException(404, "Инструкция не найдена.")
        require_fresh()
        doc = store.existing(scope, identity)
        if not doc or doc["status"] != "ready":
            raise HTTPException(404, "Эта версия инструкции больше недоступна.")
        return {"title": doc["title"], "pages": doc["pages"], "fingerprint": doc["fingerprint"],
                "url": safe_url(doc.get("url")), "preview": preview}

