import asyncio
import json
import sys
import time

from .bitrix import Bitrix, UpstreamError
from .config import Settings, Source
from .store import Store, digest


async def extract_pdf(data):
    process = await asyncio.create_subprocess_exec(
        sys.executable, "-m", "knowledge.pdf_extract",
        stdin=asyncio.subprocess.PIPE, stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.DEVNULL,
    )
    try:
        stdout, _ = await asyncio.wait_for(process.communicate(data), timeout=45)
        if process.returncode != 0:
            return {"pages": [], "status": "extraction_failed"}
        return json.loads(stdout)
    except (asyncio.TimeoutError, ValueError):
        return {"pages": [], "status": "extraction_failed"}
    finally:
        if process.returncode is None:
            process.kill()
            await process.wait()


class Synchronizer:
    def __init__(self, settings: Settings, store: Store, bitrix: Bitrix):
        self.settings, self.store, self.bitrix = settings, store, bitrix
        self.lock = asyncio.Lock()

    async def document(self, source: Source, item: dict):
        if source.kind == "note":
            identity = str(item["id"])
            data = (await self.bitrix.call("note.document.get", {"id": int(identity)}, v3=True))["result"]["item"]
            if str(data["collectionId"]) != str(source.id):
                raise UpstreamError("Document changed collection during synchronization")
            pages = [data["markdown"]]
            # Markdown is imported; attached binaries require their own Disk source.
            # Review prevents attachments from being silently treated as indexed knowledge.
            status = "needs_review"
            revision = str(data["updatedAt"])
            title, url = data["title"], None
        else:
            identity = str(item["ID"])
            data = (await self.bitrix.call("disk.file.get", {"id": int(identity)}))["result"]
            if str(data.get("DELETED_TYPE", "0")) != "0":
                raise UpstreamError("File changed during synchronization")
            revision = digest([data["GLOBAL_CONTENT_VERSION"], data["UPDATE_TIME"], data["SIZE"], data["NAME"]])
            title, url = data["NAME"], data.get("DETAIL_URL")
            old = self.store.existing(source.key, identity)
            if old and old["revision"] == revision and old["status"] in {"ready", "needs_review"}:
                old["url"] = url
                if not self.settings.require_review:
                    old["status"] = "ready"
                return old
            if int(data["SIZE"]) > self.settings.max_file_bytes:
                pages, status = [], "file_too_large"
            else:
                output = await extract_pdf(await self.bitrix.download(data["DOWNLOAD_URL"]))
                pages, status = output["pages"], output["status"]
        if status == "needs_review" and not self.settings.require_review:
            status = "ready"
        return {"id": identity, "title": title, "url": url, "revision": revision,
                "pages": pages, "status": status,
                "fingerprint": digest([source.key, identity, revision, title, pages])}

    async def run_once(self):
        async with self.lock:
            success = True
            for source in self.settings.sources:
                try:
                    items = await self.bitrix.list_items(source)
                    documents = []
                    for item in items:
                        documents.append(await self.document(source, item))
                    self.store.snapshot(source.key, documents)
                except Exception:
                    # A failed/partial scan must neither delete documents nor serve stale knowledge.
                    # No provider exception text is logged; it may contain webhook secrets.
                    self.store.fail(source.key)
                    success = False
            return success

    async def worker(self):
        self.store.request()
        next_poll = time.monotonic() + self.settings.poll_seconds
        while True:
            if time.monotonic() >= next_poll:
                self.store.request()
                next_poll = time.monotonic() + self.settings.poll_seconds
            ticket = self.store.ticket()
            if ticket is not None:
                self.store.finish(ticket, await self.run_once())
            await asyncio.sleep(1)
