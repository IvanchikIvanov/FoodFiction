import asyncio
from urllib.parse import urljoin, urlsplit

import httpx

from .config import Settings, Source


class UpstreamError(Exception):
    """Messages must never include credentials, downloaded URLs or response bodies."""


class Bitrix:
    def __init__(self, settings: Settings, client: httpx.AsyncClient):
        self.settings = settings
        self.client = client

    async def call(self, method: str, params: dict, *, v3=False):
        path = "rest/api" if v3 else "rest"
        suffix = "" if v3 else ".json"
        url = (f"{self.settings.portal_url.rstrip('/')}/{path}/"
               f"{self.settings.user_id}/{self.settings.webhook_key}/{method}{suffix}")
        for attempt in range(3):
            try:
                # Never follow an API redirect: the URL contains a secret.
                response = await self.client.post(url, json=params, follow_redirects=False)
                if response.status_code == 429 or response.status_code >= 500:
                    if attempt < 2:
                        await asyncio.sleep(0.5 * 2**attempt)
                        continue
                if not response.is_success:
                    raise UpstreamError(f"Bitrix request rejected ({response.status_code})")
                data = response.json()
                if not isinstance(data, dict) or data.get("error") or "result" not in data:
                    raise UpstreamError("Bitrix returned an error or unknown response format")
                return data
            except (httpx.HTTPError, ValueError):
                if attempt == 2:
                    raise UpstreamError("Bitrix connection or response failure") from None
                await asyncio.sleep(0.5 * 2**attempt)
        raise UpstreamError("Bitrix unavailable")

    async def disk_items(self, root: int):
        folders = [root]
        visited = set()
        found = {}
        while folders:
            folder = folders.pop()
            if folder in visited:
                raise UpstreamError("Cyclic or duplicate folder tree")
            visited.add(folder)
            cursor = 0
            cursors = set()
            while True:
                if cursor in cursors:
                    raise UpstreamError("Repeated pagination cursor")
                cursors.add(cursor)
                data = await self.call("disk.folder.getChildren", {"id": folder, "start": cursor})
                if not isinstance(data["result"], list):
                    raise UpstreamError("Invalid folder listing")
                for item in data["result"]:
                    if str(item.get("DELETED_TYPE", "0")) != "0":
                        continue
                    identity = int(item["ID"])
                    if item["TYPE"] == "folder":
                        folders.append(identity)
                    elif item["TYPE"] == "file" and item["NAME"].lower().endswith(".pdf"):
                        found[identity] = item
                    if len(found) + len(visited) + len(folders) > self.settings.max_documents:
                        raise UpstreamError("Configured source size limit exceeded")
                next_cursor = data.get("next")
                if next_cursor is None:
                    break
                cursor = int(next_cursor)
        return list(found.values())

    async def note_items(self, collection: int):
        data = (await self.call("note.document.tree.list", {"collectionId": collection}, v3=True))["result"]
        if not isinstance(data, dict) or data.get("truncated") is not False:
            raise UpstreamError("Knowledge tree is truncated or completeness is unknown")
        stack = list(data["items"])
        seen = set()
        documents = []
        while stack:
            node = stack.pop()
            identity = int(node["id"])
            if identity in seen:
                raise UpstreamError("Duplicate knowledge tree node")
            seen.add(identity)
            documents.append(node)
            stack.extend(node.get("children", []))
            if len(seen) > self.settings.max_documents:
                raise UpstreamError("Configured source size limit exceeded")
        return documents

    async def list_items(self, source: Source):
        if source.kind == "disk":
            return await self.disk_items(source.id)
        return await self.note_items(source.id)

    async def download(self, url: str):
        allowed = {self.settings.domain, *self.settings.download_hosts}
        for _ in range(5):
            parsed = urlsplit(url)
            if (parsed.scheme != "https" or parsed.hostname not in allowed
                    or parsed.username or parsed.password or parsed.port not in {None, 443}):
                raise UpstreamError("Download host is not approved")
            try:
                async with self.client.stream("GET", url, follow_redirects=False) as response:
                    if response.is_redirect:
                        location = response.headers.get("location")
                        if not location:
                            raise UpstreamError("Invalid download redirect")
                        url = urljoin(url, location)
                        continue
                    if not response.is_success:
                        raise UpstreamError("Download failed")
                    output = bytearray()
                    async for chunk in response.aiter_bytes():
                        output.extend(chunk)
                        if len(output) > self.settings.max_file_bytes:
                            raise UpstreamError("PDF exceeds size limit")
                    return bytes(output)
            except httpx.HTTPError:
                raise UpstreamError("Download connection failed") from None
        raise UpstreamError("Too many download redirects")

