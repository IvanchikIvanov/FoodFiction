import json
import os
from dataclasses import dataclass, field
from pathlib import Path
from urllib.parse import urlsplit


@dataclass(frozen=True)
class Source:
    kind: str
    id: int

    def __post_init__(self):
        if self.kind not in {"disk", "note"} or self.id <= 0:
            raise ValueError("Source must be disk/note with a positive id")

    @property
    def key(self):
        return f"{self.kind}:{self.id}"


@dataclass(frozen=True)
class Settings:
    portal_url: str
    user_id: int
    sources: tuple[Source, ...]
    webhook_key: str = field(repr=False)
    api_token: str = field(repr=False)
    event_token: str = field(default="", repr=False)
    database: str = "data/knowledge.sqlite3"
    poll_seconds: int = 300
    max_stale_seconds: int = 900
    download_hosts: tuple[str, ...] = ()
    max_file_bytes: int = 20 * 1024 * 1024
    max_documents: int = 10000
    require_review: bool = True
    web_access_code: str = field(default="", repr=False)
    web_scopes: tuple[str, ...] = ()
    web_cookie_secure: bool = True

    def __post_init__(self):
        url = urlsplit(self.portal_url)
        if (url.scheme != "https" or not url.hostname or url.username or url.password
                or url.path not in {"", "/"} or url.query or url.fragment or url.port not in {None, 443}):
            raise ValueError("portal_url must be an HTTPS origin")
        if self.user_id <= 0 or not self.webhook_key.isalnum():
            raise ValueError("Valid Bitrix user id and webhook key are required")
        if len(self.api_token) < 32:
            raise ValueError("KNOWLEDGE_API_TOKEN must be at least 32 characters")
        if not self.sources or len({s.key for s in self.sources}) != len(self.sources):
            raise ValueError("Configure distinct source folders/collections")
        if self.poll_seconds < 10 or self.max_stale_seconds < self.poll_seconds:
            raise ValueError("Invalid synchronization intervals")
        if not set(self.web_scopes) <= {s.key for s in self.sources}:
            raise ValueError("web_scopes must refer to configured sources")
        if self.web_access_code and (len(self.web_access_code) < 16 or self.web_access_code == self.api_token):
            raise ValueError("Use a separate web access code of at least 16 characters")

    @property
    def domain(self):
        return urlsplit(self.portal_url).hostname

    @classmethod
    def load(cls):
        path = Path(os.environ.get("KNOWLEDGE_SETTINGS", "settings.json"))
        raw = json.loads(path.read_text(encoding="utf-8-sig"))
        raw["sources"] = tuple(Source(**s) for s in raw["sources"])
        raw["download_hosts"] = tuple(raw.get("download_hosts", []))
        raw["web_scopes"] = tuple(raw.get("web_scopes", []))
        return cls(**raw, webhook_key=os.environ.get("BITRIX_WEBHOOK_KEY", ""),
                   api_token=os.environ.get("KNOWLEDGE_API_TOKEN", ""),
                   event_token=os.environ.get("BITRIX_EVENT_TOKEN", ""),
                   web_access_code=os.environ.get("KNOWLEDGE_WEB_ACCESS_CODE", ""))
