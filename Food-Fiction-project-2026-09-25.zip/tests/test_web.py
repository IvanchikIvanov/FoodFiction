from dataclasses import replace

import pytest
from fastapi.testclient import TestClient

from knowledge.app import create_app
from knowledge.config import Settings, Source
from knowledge.store import digest


@pytest.fixture
def settings(tmp_path):
    return Settings(portal_url="https://example.bitrix24.ru", user_id=1,
                    sources=(Source("note", 1), Source("note", 2)), webhook_key="privatekey",
                    api_token="admin-"+"a"*32, database=str(tmp_path / "web.db"),
                    web_access_code="employee-"+"b"*24, web_scopes=("note:1",), web_cookie_secure=False)


def seed(store):
    for scope, text in [("note:1", "Пропуск для сотрудников"), ("note:2", "Пропуск руководителя — секрет")]:
        store.snapshot(scope, [{"id": "1", "title": "Пропуска", "pages": [text], "revision": "1",
                               "fingerprint": digest(text), "status": "ready", "url": "javascript:alert(1)"}])


def test_home_and_assets_never_contain_credentials(settings):
    with TestClient(create_app(settings, background=False)) as client:
        for path in ["/", "/assets/app.js", "/assets/styles.css"]:
            result = client.get(path)
            assert result.status_code == 200
            assert settings.api_token not in result.text
            assert settings.web_access_code not in result.text
            assert settings.webhook_key not in result.text
            assert result.headers["x-content-type-options"] == "nosniff"
        assert "Food Fiction" in client.get("/").text


def test_web_login_only_grants_configured_read_scopes(settings):
    app = create_app(settings, background=False)
    with TestClient(app) as client:
        seed(app.state.store)
        query = {"query": "Пропуск", "scopes": ["note:2"]}
        assert client.post("/api/web/search", json=query).status_code == 401
        assert client.post("/api/web/login", json={"code": settings.api_token}).status_code == 401
        login = client.post("/api/web/login", json={"code": settings.web_access_code})
        assert login.status_code == 200
        assert "HttpOnly" in login.headers["set-cookie"]
        assert "SameSite=strict" in login.headers["set-cookie"]
        response = client.post("/api/web/search", json=query)
        assert response.status_code == 200
        assert {r["scope"] for r in response.json()["results"]} == {"note:1"}
        assert response.json()["results"][0]["url"] is None
        assert client.get("/api/web/documents/note:2/1").status_code == 404
        assert client.get("/admin/status").status_code == 401
        assert client.post("/admin/sync").status_code == 401
        assert client.post("/api/web/logout").status_code == 200
        assert client.get("/api/web/documents/note:1/1").status_code == 401


def test_web_rejects_cross_origin_login_and_brute_force(settings):
    with TestClient(create_app(settings, background=False)) as client:
        assert client.post("/api/web/login", headers={"Origin": "https://evil.example"},
                           json={"code": settings.web_access_code}).status_code == 403
        for _ in range(5):
            assert client.post("/api/web/login", json={"code": "wrong"}).status_code == 401
        assert client.post("/api/web/login", json={"code": settings.web_access_code}).status_code == 429


def test_web_source_disappears_after_revocation_or_sync_failure(settings):
    app = create_app(settings, background=False)
    with TestClient(app) as client:
        seed(app.state.store)
        client.post("/api/web/login", json={"code": settings.web_access_code})
        assert client.get("/api/web/documents/note:1/1").status_code == 200
        app.state.store.snapshot("note:1", [])
        assert client.get("/api/web/documents/note:1/1").status_code == 404
        app.state.store.fail("note:1")
        assert client.post("/api/web/search", json={"query": "Пропуск"}).status_code == 503


def test_web_access_is_disabled_by_default(settings):
    with TestClient(create_app(replace(settings, web_access_code="", web_scopes=()), background=False)) as client:
        assert not client.get("/api/web/status").json()["configured"]
        assert client.post("/api/web/login", json={"code": "anything"}).status_code == 503
        assert client.post("/api/web/search", json={"query": "Пропуск"}).status_code == 401


def test_preview_is_explicit_and_read_only(settings):
    app = create_app(settings, background=False, preview=True)
    with TestClient(app) as client:
        seed(app.state.store)
        assert client.get("/api/web/status").json()["preview"] is True
        assert client.post("/api/web/search", json={"query": "Пропуск"}).json()["preview"] is True
        assert client.get("/admin/status").status_code == 401


def test_admin_key_cannot_be_reused_as_employee_code(settings):
    with pytest.raises(ValueError, match="separate web access"):
        replace(settings, web_access_code=settings.api_token)
